#!/bin/bash

# Configuration
API_TOKEN="eoDj5yL0gajikkDq7B8CwHPkyLDBPBafa-0OsNm4"
ZONE_ID="7ecfec721b5967adec13dc84d6686ea2"
DOMAIN="fixie.run"

# Function to make Cloudflare API calls
cf_api() {
    local method=$1
    local endpoint=$2
    local data=$3
    
    curl -s -X "$method" \
        "https://api.cloudflare.com/client/v4/$endpoint" \
        -H "Authorization: Bearer $API_TOKEN" \
        -H "Content-Type: application/json" \
        --data "$data"
}

echo "Configuring Cloudflare settings for $DOMAIN..."

# Enable all security features
echo "Enabling security features..."
cf_api PATCH "zones/$ZONE_ID/settings/security_level" \
    '{"value":"high"}'

cf_api PATCH "zones/$ZONE_ID/settings/browser_check" \
    '{"value":"on"}'

cf_api PATCH "zones/$ZONE_ID/settings/bot_fight_mode" \
    '{"value":"on"}'

cf_api PATCH "zones/$ZONE_ID/settings/waf" \
    '{"value":"on"}'

# Enable performance features
echo "Enabling performance features..."
cf_api PATCH "zones/$ZONE_ID/settings/brotli" \
    '{"value":"on"}'

cf_api PATCH "zones/$ZONE_ID/settings/polish" \
    '{"value":"lossless"}'

cf_api PATCH "zones/$ZONE_ID/settings/minify" \
    '{"value":{"css":"on","html":"on","js":"on"}}'

cf_api PATCH "zones/$ZONE_ID/settings/rocket_loader" \
    '{"value":"on"}'

# Configure cache rules
echo "Setting up cache rules..."
cf_api POST "zones/$ZONE_ID/pagerules" '{
    "targets": [{"target": "url", "constraint": {"operator": "matches", "value": "*fixie.run/*"}}],
    "actions": [
        {"id": "cache_level", "value": "cache_everything"},
        {"id": "edge_cache_ttl", "value": 7200},
        {"id": "browser_cache_ttl", "value": 1800},
        {"id": "always_online", "value": "on"}
    ],
    "status": "active"
}'

cf_api POST "zones/$ZONE_ID/pagerules" '{
    "targets": [{"target": "url", "constraint": {"operator": "matches", "value": "*fixie.run/api/*"}}],
    "actions": [
        {"id": "cache_level", "value": "bypass"},
        {"id": "security_level", "value": "high"}
    ],
    "status": "active"
}'

cf_api POST "zones/$ZONE_ID/pagerules" '{
    "targets": [{"target": "url", "constraint": {"operator": "matches", "value": "*fixie.run/static/*"}}],
    "actions": [
        {"id": "cache_level", "value": "cache_everything"},
        {"id": "edge_cache_ttl", "value": 31536000},
        {"id": "browser_cache_ttl", "value": 31536000}
    ],
    "status": "active"
}'

echo "Cloudflare configuration completed!"
