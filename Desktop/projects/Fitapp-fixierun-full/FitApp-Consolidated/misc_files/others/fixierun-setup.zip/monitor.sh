#!/bin/bash

# Configuration
SLACK_WEBHOOK_URL="YOUR_SLACK_WEBHOOK_URL"
LOG_DIR="/var/log/nginx"
THRESHOLD_CPU=80
THRESHOLD_MEMORY=80
THRESHOLD_DISK=90

# Function to send Slack notification
send_slack_notification() {
    local message="$1"
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"🚨 ALERT - FIXIE.RUN: $message\"}" \
        $SLACK_WEBHOOK_URL
}

# Monitor CPU usage
cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d. -f1)
if [ "$cpu_usage" -gt "$THRESHOLD_CPU" ]; then
    send_slack_notification "High CPU usage: ${cpu_usage}%"
fi

# Monitor memory usage
memory_usage=$(free | grep Mem | awk '{print $3/$2 * 100.0}' | cut -d. -f1)
if [ "$memory_usage" -gt "$THRESHOLD_MEMORY" ]; then
    send_slack_notification "High memory usage: ${memory_usage}%"
fi

# Monitor disk usage
disk_usage=$(df -h / | awk 'NR==2 {print $5}' | cut -d% -f1)
if [ "$disk_usage" -gt "$THRESHOLD_DISK" ]; then
    send_slack_notification "High disk usage: ${disk_usage}%"
fi

# Monitor HTTP errors
error_count=$(grep "HTTP/[1-2].[0-9]\" [45]" $LOG_DIR/fixierun.access.log | wc -l)
if [ "$error_count" -gt 10 ]; then
    send_slack_notification "High number of HTTP errors in the last minute: ${error_count}"
fi

# Monitor response time
avg_response_time=$(tail -n 1000 $LOG_DIR/fixierun.access.log | awk '{sum+=$NF} END {print sum/NR}')
if (( $(echo "$avg_response_time > 2.0" | bc -l) )); then
    send_slack_notification "High average response time: ${avg_response_time}s"
fi

# Create daily report
echo "=== Daily Report $(date) ===" > /var/log/fixierun_daily_report.log
echo "Average CPU Usage: ${cpu_usage}%" >> /var/log/fixierun_daily_report.log
echo "Memory Usage: ${memory_usage}%" >> /var/log/fixierun_daily_report.log
echo "Disk Usage: ${disk_usage}%" >> /var/log/fixierun_daily_report.log
echo "Total HTTP Errors: ${error_count}" >> /var/log/fixierun_daily_report.log
echo "Average Response Time: ${avg_response_time}s" >> /var/log/fixierun_daily_report.log
