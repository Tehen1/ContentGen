#!/bin/bash

# Configuration
DOMAIN="fixie.run"
EMAIL="dwtehen1@gmail.com"
PROJECT_PATH="/var/www/fixierun"

# Colors for output
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${GREEN}Starting server setup for $DOMAIN...${NC}"

# Update system
echo -e "${GREEN}Updating system packages...${NC}"
apt-get update
apt-get upgrade -y

# Install required packages
echo -e "${GREEN}Installing required packages...${NC}"
apt-get install -y nginx certbot python3-certbot-nginx iptables-persistent fail2ban bc curl

# Create project directory
echo -e "${GREEN}Setting up project directory...${NC}"
mkdir -p $PROJECT_PATH
chown -R www-data:www-data $PROJECT_PATH

# Configure Nginx
echo -e "${GREEN}Configuring Nginx...${NC}"
cp nginx-ssl.conf /etc/nginx/sites-available/$DOMAIN
ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# Install SSL certificate
echo -e "${GREEN}Installing SSL certificate...${NC}"
certbot --nginx -d $DOMAIN -d *.$DOMAIN --non-interactive --agree-tos --email $EMAIL

# Configure firewall
echo -e "${GREEN}Configuring firewall...${NC}"
bash setup-firewall.sh

# Setup monitoring
echo -e "${GREEN}Setting up monitoring...${NC}"
cp monitor.sh /usr/local/bin/
chmod +x /usr/local/bin/monitor.sh

# Configure fail2ban
echo -e "${GREEN}Configuring fail2ban...${NC}"
cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-botsearch]
enabled = true
filter = nginx-botsearch
port = http,https
logpath = /var/log/nginx/access.log
maxretry = 2
EOF

systemctl restart fail2ban

# Setup log rotation
echo -e "${GREEN}Configuring log rotation...${NC}"
cat > /etc/logrotate.d/fixierun << EOF
/var/log/nginx/*log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data adm
    sharedscripts
    prerotate
        if [ -d /etc/logrotate.d/httpd-prerotate ]; then \
            run-parts /etc/logrotate.d/httpd-prerotate; \
        fi \
    endscript
    postrotate
        invoke-rc.d nginx rotate >/dev/null 2>&1
    endscript
}
EOF

# Setup cron jobs
echo -e "${GREEN}Setting up cron jobs...${NC}"
(crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/monitor.sh") | crontab -
(crontab -l 2>/dev/null; echo "0 0 * * * certbot renew --quiet") | crontab -

# Configure Cloudflare
echo -e "${GREEN}Configuring Cloudflare...${NC}"
bash setup-cloudflare.sh

# Final steps
echo -e "${GREEN}Setup completed!${NC}"
echo -e "Please check the following:"
echo "1. Nginx configuration: nginx -t"
echo "2. SSL certificate: certbot certificates"
echo "3. Firewall status: iptables -L"
echo "4. Fail2ban status: fail2ban-client status"
echo "5. Monitor script: /usr/local/bin/monitor.sh"
echo "6. Cloudflare dashboard for DNS and security settings"
