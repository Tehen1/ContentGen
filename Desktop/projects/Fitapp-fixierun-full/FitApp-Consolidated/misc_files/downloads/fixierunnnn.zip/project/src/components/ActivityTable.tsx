import React from 'react';
import { Activity } from '../types/Activity';

interface ActivityTableProps {
  activities: Activity[];
}

const ActivityTable: React.FC<ActivityTableProps> = ({ activities }) => {
  // Sort by date (newest first) and take the most recent 100
  const sortedActivities = [...activities]
    .sort((a, b) => new Date(b.start_time).getTime() - new Date(a.start_time).getTime())
    .slice(0, 100);

  if (activities.length === 0) {
    return (
      <div className="p-6 text-center text-gray-500 dark:text-gray-400 italic">
        No activities found for the selected filters
      </div>
    );
  }

  return (
    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
      <thead className="bg-gray-50 dark:bg-slate-700">
        <tr>
          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
            Date
          </th>
          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
            Time
          </th>
          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
            Activity
          </th>
          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
            Distance (km)
          </th>
          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
            Duration (min)
          </th>
        </tr>
      </thead>
      <tbody className="bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-gray-700">
        {sortedActivities.map((activity, index) => {
          // Calculate duration in minutes
          const start = new Date(activity.start_time.replace(' ', 'T'));
          const end = new Date(activity.end_time.replace(' ', 'T'));
          const durationMinutes = (end.getTime() - start.getTime()) / (1000 * 60);
          
          // Format date and time
          const dateParts = activity.start_time.split(' ')[0].split('-');
          const formattedDate = `${dateParts[0]}-${dateParts[1]}-${dateParts[2]}`;
          const formattedTime = activity.start_time.split(' ')[1].substring(0, 5);
          
          return (
            <tr key={index} className="hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors">
              <td className="px-4 py-2 whitespace-nowrap">
                {formattedDate}
              </td>
              <td className="px-4 py-2 whitespace-nowrap">
                {formattedTime}
              </td>
              <td className="px-4 py-2 whitespace-nowrap capitalize">
                {activity.activity_type}
              </td>
              <td className="px-4 py-2 whitespace-nowrap">
                {activity.distance_km.toFixed(2)}
              </td>
              <td className="px-4 py-2 whitespace-nowrap">
                {durationMinutes.toFixed(1)}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default ActivityTable;