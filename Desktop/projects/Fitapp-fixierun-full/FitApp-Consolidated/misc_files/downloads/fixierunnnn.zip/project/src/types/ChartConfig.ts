import { ChartData, ChartOptions } from 'chart.js';

export interface ChartConfig {
  id: string;
  options: ChartOptions;
  data: ChartData;
}