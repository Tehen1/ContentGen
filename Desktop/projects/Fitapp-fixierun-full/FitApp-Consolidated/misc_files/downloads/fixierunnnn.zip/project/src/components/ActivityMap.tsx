import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import { Activity } from '../types/Activity';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for Leaflet marker icons in React
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface ActivityMapProps {
  activities: Activity[];
}

// Component to fit bounds when markers change
const MapBoundsFitter = ({ activities }: { activities: Activity[] }) => {
  const map = useMap();
  
  useEffect(() => {
    if (activities.length === 0) {
      map.setView([50.642, 5.581], 13);
      return;
    }
    
    // Sample some activities for the map (to avoid too many markers)
    const sampleSize = Math.min(50, activities.length);
    const step = Math.floor(activities.length / sampleSize) || 1;
    const sampledActivities = [];
    
    for (let i = 0; i < activities.length; i += step) {
      sampledActivities.push(activities[i]);
      if (sampledActivities.length >= sampleSize) break;
    }
    
    // Create bounds
    const bounds = L.latLngBounds([]);
    
    sampledActivities.forEach(activity => {
      if (activity.start_lat && activity.start_lon) {
        bounds.extend([activity.start_lat, activity.start_lon]);
      }
      
      if (activity.end_lat && activity.end_lon) {
        bounds.extend([activity.end_lat, activity.end_lon]);
      }
    });
    
    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [activities, map]);
  
  return null;
};

const ActivityMap: React.FC<ActivityMapProps> = ({ activities }) => {
  if (activities.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-50 dark:bg-slate-700">
        <p className="text-gray-500 dark:text-gray-400 italic">No activities to display on map</p>
      </div>
    );
  }
  
  // Sample some activities for the map (to avoid too many markers)
  const sampleSize = Math.min(50, activities.length);
  const step = Math.floor(activities.length / sampleSize) || 1;
  const sampledActivities = [];
  
  for (let i = 0; i < activities.length; i += step) {
    sampledActivities.push(activities[i]);
    if (sampledActivities.length >= sampleSize) break;
  }

  return (
    <MapContainer
      center={[50.642, 5.581]}
      zoom={13}
      style={{ height: '100%', width: '100%' }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      <MapBoundsFitter activities={sampledActivities} />
      
      {sampledActivities.map((activity, index) => {
        if (!activity.start_lat || !activity.start_lon) return null;
        
        // Format date for popup
        const date = new Date(activity.start_time.replace(' ', 'T'));
        const formattedDate = date.toLocaleDateString();
        const formattedTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        return (
          <React.Fragment key={index}>
            <Marker position={[activity.start_lat, activity.start_lon]}>
              <Popup>
                <strong>{formattedDate} {formattedTime}</strong><br />
                Activity: {activity.activity_type}<br />
                Distance: {activity.distance_km.toFixed(2)} km
              </Popup>
            </Marker>
            
            {/* Add polyline if activity has end coordinates */}
            {activity.end_lat && activity.end_lon && (
              <Polyline
                positions={[
                  [activity.start_lat, activity.start_lon],
                  [activity.end_lat, activity.end_lon]
                ]}
                color="#5D5CDE"
                weight={2}
                opacity={0.7}
              />
            )}
          </React.Fragment>
        );
      })}
    </MapContainer>
  );
};

export default ActivityMap;