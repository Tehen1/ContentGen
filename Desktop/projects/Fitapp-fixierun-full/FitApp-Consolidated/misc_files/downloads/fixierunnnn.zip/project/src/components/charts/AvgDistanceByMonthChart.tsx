import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import { Activity } from '../../types/Activity';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  PointElement,
  LineElement,
  Title, 
  Tooltip, 
  Legend,
  Filler
} from 'chart.js';
import zoomPlugin from 'chartjs-plugin-zoom';

ChartJS.register(
  CategoryScale, 
  LinearScale, 
  PointElement,
  LineElement,
  Title, 
  Tooltip, 
  Legend,
  Filler,
  zoomPlugin
);

interface AvgDistanceByMonthChartProps {
  activities: Activity[];
}

const AvgDistanceByMonthChart: React.FC<AvgDistanceByMonthChartProps> = ({ activities }) => {
  const chartRef = React.useRef<ChartJS>(null);
  
  const chartData = useMemo(() => {
    // Calculate average distance by month
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const distanceByMonth = Array(12).fill(0);
    const countByMonth = Array(12).fill(0);
    
    activities.forEach(activity => {
      const month = parseInt(activity.start_time.split('-')[1]) - 1; // 0-based month
      distanceByMonth[month] += activity.distance_km;
      countByMonth[month]++;
    });
    
    const avgDistanceByMonth = distanceByMonth.map((total, i) => {
      return countByMonth[i] > 0 ? parseFloat((total / countByMonth[i]).toFixed(1)) : 0;
    });
    
    return {
      labels: monthNames,
      datasets: [{
        label: 'Avg Distance (km)',
        data: avgDistanceByMonth,
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4
      }]
    };
  }, [activities]);
  
  const resetZoom = () => {
    if (chartRef.current) {
      chartRef.current.resetZoom();
    }
  };

  // If no data, show empty state
  if (activities.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <p className="text-gray-500 dark:text-gray-400 italic">No activity data to display</p>
      </div>
    );
  }

  return (
    <div className="h-[300px] relative">
      <div className="text-right mb-2">
        <button 
          className="bg-purple-600 text-white px-2 py-1 text-sm rounded hover:bg-purple-700 transition-colors"
          onClick={resetZoom}
        >
          Reset
        </button>
      </div>
      <Line
        ref={chartRef}
        data={chartData}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'Avg Distance (km)',
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              },
              ticks: {
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              },
              grid: {
                color: document.documentElement.classList.contains('dark') ? 'rgba(255, 255, 255, 0.1)' : undefined
              }
            },
            x: {
              ticks: {
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              },
              grid: {
                color: document.documentElement.classList.contains('dark') ? 'rgba(255, 255, 255, 0.1)' : undefined
              }
            }
          },
          plugins: {
            legend: {
              display: true,
              labels: {
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              }
            },
            zoom: {
              pan: {
                enabled: true,
                mode: 'xy',
                threshold: 5
              },
              zoom: {
                wheel: {
                  enabled: true
                },
                pinch: {
                  enabled: true
                },
                mode: 'xy'
              }
            }
          }
        }}
      />
    </div>
  );
};

export default AvgDistanceByMonthChart;