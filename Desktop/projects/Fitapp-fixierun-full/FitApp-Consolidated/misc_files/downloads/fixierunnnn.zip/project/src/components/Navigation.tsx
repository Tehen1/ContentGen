import { useAppStore } from '@/store/useAppStore';
import { Home, Map, Package, ShoppingBag, User } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Navigation() {
  const currentScreen = useAppStore((state) => state.currentScreen);
  const setScreen = useAppStore((state) => state.setScreen);

  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Home' },
    { id: 'track', icon: Map, label: 'Track' },
    { id: 'nft', icon: Package, label: 'NFTs' },
    { id: 'market', icon: ShoppingBag, label: 'Market' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 shadow-md backdrop-blur-md bg-opacity-90 dark:bg-opacity-90 border-t border-gray-200 dark:border-gray-800">
      <div className="container mx-auto max-w-md">
        <div className="flex justify-between items-center py-3 px-6">
          {navItems.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => setScreen(id)}
              className={cn(
                "flex flex-col items-center",
                currentScreen === id
                  ? "text-primary"
                  : "text-gray-500 dark:text-gray-400"
              )}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs mt-1">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}