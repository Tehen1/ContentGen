import { useAppStore } from '@/store/useAppStore';
import { Activity, Bike, Clock, Ruler } from 'lucide-react';
import { StatCard } from './StatCard';

export function StatCards() {
  const activities = useAppStore((state) => state.activities);
  
  const stats = {
    totalActivities: activities.length,
    totalDistance: activities.reduce((sum, a) => sum + a.distance, 0),
    totalHours: activities.reduce((sum, a) => sum + a.duration, 0) / (1000 * 60 * 60),
    avgDistance: activities.length > 0
      ? activities.reduce((sum, a) => sum + a.distance, 0) / activities.length
      : 0,
  };

  const hasData2025 = activities.some(
    (activity) => activity.startTime.getFullYear() === 2025
  );

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <StatCard
        icon={<Activity size={32} />}
        value={stats.totalActivities.toLocaleString()}
        label="Total Activities"
        highlight={hasData2025}
      />
      <StatCard
        icon={<Bike size={32} />}
        value={stats.totalDistance.toFixed(1)}
        label="Total Kilometers"
        highlight={hasData2025}
      />
      <StatCard
        icon={<Clock size={32} />}
        value={stats.totalHours.toFixed(1)}
        label="Total Hours"
        highlight={hasData2025}
      />
      <StatCard
        icon={<Ruler size={32} />}
        value={stats.avgDistance.toFixed(1)}
        label="Avg Distance (km)"
        highlight={hasData2025}
      />
    </div>
  );
}