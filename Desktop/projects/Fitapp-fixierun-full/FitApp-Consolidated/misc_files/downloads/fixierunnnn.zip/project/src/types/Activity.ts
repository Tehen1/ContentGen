export interface Activity {
  start_time: string;
  end_time: string;
  activity_type: string;
  distance_km: number;
  start_lat: number;
  start_lon: number;
  end_lat: number;
  end_lon: number;
  confidence: number;
}