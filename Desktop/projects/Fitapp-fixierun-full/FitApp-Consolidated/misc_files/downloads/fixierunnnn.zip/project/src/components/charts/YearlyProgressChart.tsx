import React, { useMemo } from 'react';
import { Bar } from 'react-chartjs-2';
import { Activity } from '../../types/Activity';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend 
} from 'chart.js';
import zoomPlugin from 'chartjs-plugin-zoom';

ChartJS.register(
  CategoryScale, 
  LinearScale, 
  BarElement, 
  Title, 
  Tooltip, 
  Legend,
  zoomPlugin
);

interface YearlyProgressChartProps {
  activities: Activity[];
}

const YearlyProgressChart: React.FC<YearlyProgressChartProps> = ({ activities }) => {
  const chartRef = React.useRef<ChartJS>(null);
  
  const chartData = useMemo(() => {
    // Count activities by year
    const yearCounts: Record<string, number> = {};
    
    activities.forEach(activity => {
      const year = activity.start_time.split('-')[0];
      yearCounts[year] = (yearCounts[year] || 0) + 1;
    });
    
    const years = Object.keys(yearCounts).sort();
    const counts = years.map(year => yearCounts[year]);
    
    return {
      labels: years,
      datasets: [{
        label: 'Activities',
        data: counts,
        backgroundColor: 'rgba(93, 92, 222, 0.7)',
        borderColor: 'rgba(93, 92, 222, 1)',
        borderWidth: 1
      }]
    };
  }, [activities]);
  
  const resetZoom = () => {
    if (chartRef.current) {
      chartRef.current.resetZoom();
    }
  };

  // If no data, show empty state
  if (activities.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <p className="text-gray-500 dark:text-gray-400 italic">No activity data to display</p>
      </div>
    );
  }

  return (
    <div className="h-[300px] relative">
      <div className="text-right mb-2">
        <button 
          className="bg-purple-600 text-white px-2 py-1 text-sm rounded hover:bg-purple-700 transition-colors"
          onClick={resetZoom}
        >
          Reset
        </button>
      </div>
      <Bar
        ref={chartRef}
        data={chartData}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'Number of Activities',
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              },
              ticks: {
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              },
              grid: {
                color: document.documentElement.classList.contains('dark') ? 'rgba(255, 255, 255, 0.1)' : undefined
              }
            },
            x: {
              ticks: {
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              },
              grid: {
                color: document.documentElement.classList.contains('dark') ? 'rgba(255, 255, 255, 0.1)' : undefined
              }
            }
          },
          plugins: {
            legend: {
              display: true,
              labels: {
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              }
            },
            zoom: {
              pan: {
                enabled: true,
                mode: 'xy',
                threshold: 5
              },
              zoom: {
                wheel: {
                  enabled: true
                },
                pinch: {
                  enabled: true
                },
                mode: 'xy'
              }
            }
          }
        }}
      />
    </div>
  );
};

export default YearlyProgressChart;