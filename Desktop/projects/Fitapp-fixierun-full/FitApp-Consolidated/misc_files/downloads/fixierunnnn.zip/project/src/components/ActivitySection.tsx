import React from 'react';
import { Activity } from '../types/Activity';
import ActivityTable from './ActivityTable';
import ActivityMap from './ActivityMap';

interface ActivitySectionProps {
  activities: Activity[];
}

const ActivitySection: React.FC<ActivitySectionProps> = ({ activities }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
        <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
          Recent Activities (<span>{activities.length}</span>)
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          <ActivityTable activities={activities} />
        </div>
      </div>
      
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
        <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
          Activity Map
        </div>
        <div className="h-[400px]">
          <ActivityMap activities={activities} />
        </div>
      </div>
    </div>
  );
};

export default ActivitySection;