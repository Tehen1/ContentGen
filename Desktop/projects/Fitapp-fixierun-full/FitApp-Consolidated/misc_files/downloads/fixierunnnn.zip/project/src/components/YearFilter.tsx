import React, { useEffect, useState } from 'react';
import { Activity } from '../types/Activity';

interface YearFilterProps {
  activities: Activity[];
  selectedYear: string;
  onYearChange: (year: string) => void;
}

const YearFilter: React.FC<YearFilterProps> = ({ activities, selectedYear, onYearChange }) => {
  const [years, setYears] = useState<string[]>([]);

  useEffect(() => {
    if (activities.length > 0) {
      // Get unique years from activities
      const yearSet = new Set<string>();
      
      activities.forEach(activity => {
        const year = activity.start_time.split('-')[0];
        yearSet.add(year);
      });
      
      // Sort years
      const sortedYears = Array.from(yearSet).sort();
      setYears(sortedYears);
    }
  }, [activities]);

  return (
    <div className="mb-4">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
        <div className="p-4">
          <div className="flex justify-between items-center">
            <label htmlFor="yearRange" className="text-gray-700 dark:text-gray-300 mr-3">
              Filter by Year:
            </label>
            <select 
              id="yearRange" 
              className="form-select max-w-[150px] bg-white dark:bg-slate-700 text-gray-700 dark:text-white border border-gray-300 dark:border-gray-600 rounded p-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
              value={selectedYear}
              onChange={(e) => onYearChange(e.target.value)}
            >
              <option value="all">All Years</option>
              {years.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YearFilter;