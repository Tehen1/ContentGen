import { useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { DashboardHeader } from '@/components/DashboardHeader';
import { YearFilter } from '@/components/YearFilter';
import { StatCards } from '@/components/StatCards';
import { ChartRow } from '@/components/ChartRow';
import { ActivitySection } from '@/components/ActivitySection';
import { YearlyProgressChart } from '@/components/charts/YearlyProgressChart';
import { Footer } from '@/components/Footer';
import { Navigation } from '@/components/Navigation';

export default function App() {
  const darkMode = useAppStore((state) => state.darkMode);
  
  useEffect(() => {
    // Update document class when dark mode changes
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-slate-900 dark:text-slate-200 transition-colors duration-200">
      <div className="container mx-auto px-4 py-5">
        <DashboardHeader />
        
        <YearFilter />
        
        <StatCards />
        
        <ChartRow />
        
        <ActivitySection />
        
        <div className="mt-4">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
            <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
              Yearly Activity Counts
            </div>
            <div className="p-4">
              <YearlyProgressChart />
            </div>
          </div>
        </div>
        
        <Footer />
      </div>
      
      <Navigation />
    </div>
  );
}