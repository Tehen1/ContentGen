import { useAppStore } from '@/store/useAppStore';
import { formatDistanceToNow } from 'date-fns';

export function DashboardHeader() {
  const lastUpdated = useAppStore((state) => state.lastUpdated);

  return (
    <div className="bg-gradient-to-r from-purple-600 to-indigo-700 text-white p-5 rounded-lg mb-5 shadow-md">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center">
        <div className="mb-3 md:mb-0">
          <h1 className="text-2xl md:text-3xl font-bold">
            FixieRun FitApp Dashboard
          </h1>
          <p className="text-white/90 mt-1">
            Fitness activity insights and analytics from your location history
          </p>
        </div>
        <div className="text-white/80 text-sm">
          {lastUpdated
            ? `Last updated ${formatDistanceToNow(lastUpdated)} ago`
            : 'Loading data...'}
        </div>
      </div>
    </div>
  );
}