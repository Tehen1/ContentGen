import React, { useMemo } from 'react';
import { Pie } from 'react-chartjs-2';
import { Activity } from '../../types/Activity';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, ChartData } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

interface ActivityTypeChartProps {
  activities: Activity[];
}

const ActivityTypeChart: React.FC<ActivityTypeChartProps> = ({ activities }) => {
  const chartData = useMemo(() => {
    // Count activities by type
    const activityCounts: Record<string, number> = {};
    activities.forEach(activity => {
      const type = activity.activity_type;
      activityCounts[type] = (activityCounts[type] || 0) + 1;
    });
    
    const labels = Object.keys(activityCounts)
      .map(type => type.charAt(0).toUpperCase() + type.slice(1));
    
    const data = Object.values(activityCounts);
    
    const chartData: ChartData<'pie'> = {
      labels,
      datasets: [{
        data,
        backgroundColor: [
          'rgba(93, 92, 222, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(255, 159, 64, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 99, 132, 0.7)'
        ],
        borderColor: [
          'rgba(93, 92, 222, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 99, 132, 1)'
        ],
        borderWidth: 1
      }]
    };
    
    return chartData;
  }, [activities]);
  
  // If no data, show empty state
  if (activities.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <p className="text-gray-500 dark:text-gray-400 italic">No activity data to display</p>
      </div>
    );
  }

  return (
    <div className="h-[300px] relative">
      <Pie 
        data={chartData}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                padding: 20,
                color: document.documentElement.classList.contains('dark') ? 'rgb(229, 231, 235)' : undefined
              }
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const label = context.label || '';
                  const value = context.raw as number || 0;
                  const total = (context.dataset.data as number[]).reduce((a, b) => Number(a) + Number(b), 0);
                  const percentage = Math.round((value / total) * 100);
                  return `${label}: ${value} (${percentage}%)`;
                }
              }
            }
          },
          animation: {
            duration: 800
          }
        }}
      />
    </div>
  );
};

export default ActivityTypeChart;