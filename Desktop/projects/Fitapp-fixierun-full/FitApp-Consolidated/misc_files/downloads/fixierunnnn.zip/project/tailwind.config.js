/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'media',
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#00AAFF',
          50: 'rgba(0, 170, 255, 0.05)',
          100: 'rgba(0, 170, 255, 0.1)',
          200: 'rgba(0, 170, 255, 0.2)',
          300: 'rgba(0, 170, 255, 0.3)',
          400: 'rgba(0, 170, 255, 0.4)',
          500: 'rgba(0, 170, 255, 0.5)',
          600: 'rgba(0, 170, 255, 0.7)',
          700: 'rgba(0, 136, 204, 0.8)',
          800: 'rgba(0, 136, 204, 0.9)',
          900: 'rgba(0, 136, 204, 1)',
        },
        secondary: {
          DEFAULT: '#FFAA00',
          50: 'rgba(255, 170, 0, 0.05)',
          100: 'rgba(255, 170, 0, 0.1)', 
          200: 'rgba(255, 170, 0, 0.2)',
          300: 'rgba(255, 170, 0, 0.3)',
          400: 'rgba(255, 170, 0, 0.4)',
          500: 'rgba(255, 170, 0, 0.5)',
          600: 'rgba(255, 170, 0, 0.7)',
          700: 'rgba(204, 136, 0, 0.8)',
          800: 'rgba(204, 136, 0, 0.9)',
          900: 'rgba(204, 136, 0, 1)',
        },
        dark: {
          bg: '#101010',
          card: '#1E1E1E',
          text: '#E0E0E0'
        }
      },
      animation: {
        'bounce-custom': 'bounce-custom 0.6s ease-in-out',
        'spin-coin': 'spin-coin 1s linear',
        'fade-in': 'fade-in 0.3s ease-in-out',
        'slide-up': 'slide-up 0.4s ease-out'
      },
      keyframes: {
        'bounce-custom': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-4px)' }
        },
        'spin-coin': {
          '0%': { transform: 'rotate(0)' },
          '100%': { transform: 'rotate(360deg)' }
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' }
        },
        'slide-up': {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' }
        }
      }
    }
  },
  plugins: []
}