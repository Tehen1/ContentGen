import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-6 mb-4 text-center text-gray-500 dark:text-gray-400 text-sm">
      <p>© 2025 FixieRun FitApp Tracker | All data sourced from location history (2017-2025)</p>
    </footer>
  );
};

export default Footer;