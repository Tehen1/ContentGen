import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

interface StatCardProps {
  icon: ReactNode;
  value: string;
  label: string;
  highlight?: boolean;
}

export function StatCard({ icon, value, label, highlight = false }: StatCardProps) {
  return (
    <div
      className={cn(
        "bg-white dark:bg-slate-800 rounded-lg shadow p-5 text-center transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg",
        highlight && "bg-purple-50 dark:bg-purple-900/20"
      )}
    >
      <div className="text-purple-600 dark:text-purple-400 mb-2">{icon}</div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-gray-500 dark:text-gray-400 text-sm">{label}</div>
    </div>
  );
}