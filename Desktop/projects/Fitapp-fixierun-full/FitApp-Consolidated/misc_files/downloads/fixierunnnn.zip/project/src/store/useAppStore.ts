import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Position {
  lat: number;
  lng: number;
}

interface Activity {
  id: string;
  startTime: Date;
  endTime: Date;
  distance: number;
  duration: number;
  type: 'run' | 'bike';
  path: Position[];
  points: number;
}

interface AppState {
  activities: Activity[];
  isTracking: boolean;
  currentActivity: Activity | null;
  walletConnected: boolean;
  darkMode: boolean;
  addActivity: (activity: Activity) => void;
  startTracking: (type: 'run' | 'bike') => void;
  stopTracking: () => void;
  updateCurrentActivity: (update: Partial<Activity>) => void;
  setWalletConnected: (connected: boolean) => void;
  setDarkMode: (enabled: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      activities: [],
      isTracking: false,
      currentActivity: null,
      walletConnected: false,
      darkMode: window.matchMedia('(prefers-color-scheme: dark)').matches,

      addActivity: (activity) =>
        set((state) => ({
          activities: [...state.activities, activity],
        })),

      startTracking: (type) =>
        set({
          isTracking: true,
          currentActivity: {
            id: crypto.randomUUID(),
            startTime: new Date(),
            endTime: new Date(),
            distance: 0,
            duration: 0,
            type,
            path: [],
            points: 0,
          },
        }),

      stopTracking: () =>
        set((state) => {
          if (state.currentActivity) {
            return {
              isTracking: false,
              activities: [...state.activities, state.currentActivity],
              currentActivity: null,
            };
          }
          return { isTracking: false, currentActivity: null };
        }),

      updateCurrentActivity: (update) =>
        set((state) => ({
          currentActivity: state.currentActivity
            ? { ...state.currentActivity, ...update }
            : null,
        })),

      setWalletConnected: (connected) =>
        set({ walletConnected: connected }),

      setDarkMode: (enabled) =>
        set({ darkMode: enabled }),
    }),
    {
      name: 'fixierun-storage',
    }
  )
);