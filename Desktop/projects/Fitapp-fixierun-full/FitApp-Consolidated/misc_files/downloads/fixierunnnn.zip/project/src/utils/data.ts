import { Activity } from '../types/Activity';

export function generateSampleData(): Activity[] {
  const activities: Activity[] = [];
  
  // Sample data from 2017-2025 based on actual data structure
  const years = ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'];
  const months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
  
  // Primary locations from the dataset - most activities are around Liège, Belgium
  // with some in Barcelona and other locations based on the actual data
  const locationCenters = [
    { lat: 50.642, lon: 5.588, name: "Liège Center" },
    { lat: 50.657, lon: 5.561, name: "Liège North" },
    { lat: 50.636, lon: 5.592, name: "Liège East" },
    { lat: 50.628, lon: 5.576, name: "Liège South" },
    { lat: 41.390, lon: 2.180, name: "Barcelona" }
  ];
  
  // Generate different number of activities for each year to create a natural distribution
  const activityCountByYear: Record<string, number> = {
    '2017': 350,  // Higher in early years - starting from June
    '2018': 280,
    '2019': 240,
    '2020': 170,
    '2021': 110,
    '2022': 85,
    '2023': 70,
    '2024': 65,
    '2025': 23    // Only a few months of data in 2025
  };
  
  // Actual 2025 activities from the data
  const activities2025 = [
    {
      start_time: "2025-01-07 02:00:15",
      end_time: "2025-01-07 02:20:42",
      activity_type: "cycling",
      distance_km: 5.29,
      start_lat: 50.641413,
      start_lon: 5.581392,
      end_lat: 50.629352,
      end_lon: 5.568906,
      confidence: 1.0
    },
    {
      start_time: "2025-01-23 09:00:45",
      end_time: "2025-01-23 09:10:31",
      activity_type: "cycling",
      distance_km: 2.52,
      start_lat: 50.653522,
      start_lon: 5.562561,
      end_lat: 50.642598,
      end_lon: 5.588884,
      confidence: 1.0
    },
    // More activities for January - February 2025
    {
      start_time: "2025-01-23 17:51:22",
      end_time: "2025-01-23 18:25:01",
      activity_type: "cycling",
      distance_km: 6.09,
      start_lat: 50.641532,
      start_lon: 5.581615,
      end_lat: 50.628426,
      end_lon: 5.569199,
      confidence: 1.0
    },
    {
      start_time: "2025-01-25 18:59:33",
      end_time: "2025-01-25 19:09:12",
      activity_type: "cycling",
      distance_km: 2.16,
      start_lat: 50.642029,
      start_lon: 5.581836, 
      end_lat: 50.629198,
      end_lon: 5.568223,
      confidence: 1.0
    },
    {
      start_time: "2025-01-28 11:15:24",
      end_time: "2025-01-28 11:24:18",
      activity_type: "cycling",
      distance_km: 2.30,
      start_lat: 50.647161,
      start_lon: 5.553342,
      end_lat: 50.645546,
      end_lon: 5.56103,
      confidence: 1.0
    },
    {
      start_time: "2025-02-01 21:33:16",
      end_time: "2025-02-01 21:58:22",
      activity_type: "cycling",
      distance_km: 6.53,
      start_lat: 50.641243,
      start_lon: 5.580576,
      end_lat: 50.589487,
      end_lon: 5.725486,
      confidence: 1.0
    },
    {
      start_time: "2025-02-03 15:03:19",
      end_time: "2025-02-03 15:30:04",
      activity_type: "cycling",
      distance_km: 6.34,
      start_lat: 50.642212,
      start_lon: 5.588128,
      end_lat: 50.589487,
      end_lon: 5.725486,
      confidence: 1.0
    },
    {
      start_time: "2025-02-03 15:36:22",
      end_time: "2025-02-03 15:41:14",
      activity_type: "cycling",
      distance_km: 1.25,
      start_lat: 50.589487,
      start_lon: 5.725486,
      end_lat: 50.584477,
      end_lon: 5.737795,
      confidence: 1.0
    },
    {
      start_time: "2025-02-04 18:56:33",
      end_time: "2025-02-04 19:11:12",
      activity_type: "cycling",
      distance_km: 3.36,
      start_lat: 50.589487,
      start_lon: 5.725486,
      end_lat: 50.613639,
      end_lon: 5.687787,
      confidence: 1.0
    },
    {
      start_time: "2025-02-05 12:29:14",
      end_time: "2025-02-05 12:45:24",
      activity_type: "cycling",
      distance_km: 2.52,
      start_lat: 50.613502,
      start_lon: 5.688416,
      end_lat: 50.589487,
      end_lon: 5.725486,
      confidence: 1.0
    },
    {
      start_time: "2025-02-05 18:42:06",
      end_time: "2025-02-05 19:00:29",
      activity_type: "cycling",
      distance_km: 3.76,
      start_lat: 50.589487,
      start_lon: 5.725486,
      end_lat: 50.620759,
      end_lon: 5.566489,
      confidence: 1.0
    },
    {
      start_time: "2025-02-07 00:58:19",
      end_time: "2025-02-07 01:12:24",
      activity_type: "cycling",
      distance_km: 3.65,
      start_lat: 50.620759,
      start_lon: 5.566489,
      end_lat: 50.654595,
      end_lon: 5.557946,
      confidence: 1.0
    },
    {
      start_time: "2025-02-08 18:18:54",
      end_time: "2025-02-08 18:28:37",
      activity_type: "cycling",
      distance_km: 2.16,
      start_lat: 50.646935,
      start_lon: 5.560077,
      end_lat: 50.654663,
      end_lon: 5.557898,
      confidence: 1.0
    }
  ];
  
  // Add the specific 2025 activities
  activities.push(...activities2025);
  
  // Generate the rest of the activities
  for (const year of years) {
    // Skip additional generation for 2025 since we added specific activities
    if (year === '2025') continue;
    
    const activityCount = activityCountByYear[year];
    
    for (let i = 0; i < activityCount; i++) {
      // Randomly select month with some seasonality (more in summer)
      const monthWeights = [0.05, 0.06, 0.08, 0.09, 0.1, 0.12, 0.14, 0.12, 0.09, 0.07, 0.05, 0.03];
      const monthIdx = weightedRandom(monthWeights);
      const month = months[monthIdx];
      
      // For 2017, only generate activities from June onwards
      if (year === '2017' && monthIdx < 5) continue;
      
      // Random day of month (1-28 for simplicity)
      const day = padZero(Math.floor(Math.random() * 28) + 1);
      
      // Random time
      const hour = padZero(Math.floor(Math.random() * 24));
      const minute = padZero(Math.floor(Math.random() * 60));
      const second = padZero(Math.floor(Math.random() * 60));
      
      // Create date strings
      const startDate = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
      
      // All activities are cycling based on the data
      const activityType = "cycling";
      
      // Distance - based on the typical range in the data
      let distance;
      // Most cycling trips are 1-5 km
      distance = 1 + Math.random() * 4;
      // But some are longer
      if (Math.random() < 0.15) {
        distance += Math.random() * 10;
      }
      distance = parseFloat(distance.toFixed(3));
      
      // Duration - based on activity type and distance
      // Average speed around 12-18 km/h
      const speedKmh = 12 + Math.random() * 6;
      const durationMinutes = (distance / speedKmh) * 60;
      
      // Calculate end time based on duration
      const startDateTime = new Date(startDate.replace(' ', 'T'));
      const endDateTime = new Date(startDateTime.getTime() + durationMinutes * 60 * 1000);
      const endDate = endDateTime.toISOString().replace('T', ' ').substring(0, 19);
      
      // Location - select a center and add some random variation
      let locationCenter;
      if (year === '2017' && monthIdx >= 6 && monthIdx <= 8 && Math.random() < 0.5) {
        // During summer 2017, 50% chance of activities in Barcelona (as seen in the data)
        locationCenter = locationCenters[4];
      } else {
        // Otherwise, activities in Liège area
        locationCenter = locationCenters[Math.floor(Math.random() * 4)];
      }
      
      const latVariation = (Math.random() - 0.5) * 0.02;
      const lonVariation = (Math.random() - 0.5) * 0.02;
      
      const startLat = locationCenter.lat + latVariation;
      const startLon = locationCenter.lon + lonVariation;
      
      // End location - create a random endpoint based on distance and direction
      const direction = Math.random() * Math.PI * 2; // Random direction in radians
      const latOffset = Math.sin(direction) * distance * 0.009; // ~0.009 degrees per km
      const lonOffset = Math.cos(direction) * distance * 0.014; // ~0.014 degrees per km at this latitude
      
      const endLat = startLat + latOffset;
      const endLon = startLon + lonOffset;
      
      // Create the activity object following the exact format
      activities.push({
        start_time: startDate,
        end_time: endDate,
        activity_type: activityType,
        distance_km: distance,
        start_lat: parseFloat(startLat.toFixed(6)),
        start_lon: parseFloat(startLon.toFixed(6)),
        end_lat: parseFloat(endLat.toFixed(6)),
        end_lon: parseFloat(endLon.toFixed(6)),
        confidence: Math.random() < 0.9 ? 1.0 : 0.5 // 90% of activities have high confidence
      });
    }
  }
  
  // Sort activities by date (oldest first)
  activities.sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());
  
  return activities;
}

// Helper function for weighted random selection
function weightedRandom(weights: number[]): number {
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  const randomValue = Math.random() * totalWeight;
  
  let weightSum = 0;
  for (let i = 0; i < weights.length; i++) {
    weightSum += weights[i];
    if (randomValue <= weightSum) {
      return i;
    }
  }
  
  return weights.length - 1;
}

// Helper function to pad numbers with leading zeros
function padZero(num: number): string {
  return num.toString().padStart(2, '0');
}