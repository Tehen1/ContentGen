import React from 'react';
import { Activity } from '../types/Activity';
import ActivityTypeChart from './charts/ActivityTypeChart';
import MonthlyActivityChart from './charts/MonthlyActivityChart';
import DistanceChart from './charts/DistanceChart';
import AvgDistanceByMonthChart from './charts/AvgDistanceByMonthChart';

interface ChartRowProps {
  activities: Activity[];
}

const ChartRow: React.FC<ChartRowProps> = ({ activities }) => {
  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
          <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
            Activity Distribution by Type
          </div>
          <div className="p-4">
            <ActivityTypeChart activities={activities} />
          </div>
        </div>
        
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
          <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
            Monthly Activity Distribution
          </div>
          <div className="p-4">
            <MonthlyActivityChart activities={activities} />
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
          <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
            Distance by Year
          </div>
          <div className="p-4">
            <DistanceChart activities={activities} />
          </div>
        </div>
        
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow">
          <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 font-bold">
            Average Distance by Month
          </div>
          <div className="p-4">
            <AvgDistanceByMonthChart activities={activities} />
          </div>
        </div>
      </div>
    </>
  );
};

export default ChartRow;