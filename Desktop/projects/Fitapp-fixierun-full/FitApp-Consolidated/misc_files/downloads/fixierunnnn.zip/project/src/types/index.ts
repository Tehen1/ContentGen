export interface Activity {
  id: string;
  startTime: Date;
  endTime: Date;
  distance: number;
  duration: number;
  type: 'run' | 'bike';
  path: Position[];
  points: number;
}

export interface Position {
  lat: number;
  lng: number;
}

export interface NFT {
  id: string;
  name: string;
  type: 'shoe' | 'badge' | 'collectible';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  level: number;
  boost: number;
  equipped: boolean;
  imageUrl: string;
}

export interface User {
  id: string;
  address: string;
  balance: number;
  level: number;
  experience: number;
  nfts: NFT[];
}